/*
 * Activity 4.9.3
 */
public class Wallet extends LakeObject
{  @Override
    public String say()
    {
      return "You now have a wallet!";
    }

}